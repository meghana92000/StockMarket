package com.stockmarket.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stockmarket.entity.SectorEntity;


public interface SectorRepository extends JpaRepository<SectorEntity, Integer>{
	
	public SectorEntity findBysectorName(String sectorname);
}

