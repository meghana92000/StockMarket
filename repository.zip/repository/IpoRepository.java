package com.stockmarket.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.stockmarket.entity.IPODetailEntity;
import com.stockmarket.entity.SectorEntity;

public interface IpoRepository extends JpaRepository<IPODetailEntity, Integer>{
	
	@Query(value="SELECT * FROM IPO",nativeQuery = true)
	public Page<IPODetailEntity> findallIpos(Pageable pePageable);
	
	
}

