package com.stockmarket.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.stockmarket.entity.CompanyEntity;
import com.stockmarket.entity.StockExchangeEntity;

public interface StockExchangeRepository extends JpaRepository<StockExchangeEntity, Integer> {

	@Query(value="SELECT * FROM StockExchange",nativeQuery = true)
	public Page<StockExchangeEntity> findallStockExchange(Pageable pePageable);
	
	public StockExchangeEntity findBystockExchange(String stockExchangename);
}
