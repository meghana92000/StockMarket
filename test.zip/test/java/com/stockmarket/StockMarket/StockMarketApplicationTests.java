package com.stockmarket.StockMarket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockMarketApplicationTests {

	@Test
	void contextLoads() {
	}

}
