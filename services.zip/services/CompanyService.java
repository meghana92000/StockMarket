package com.stockmarket.services;

import com.stockmarket.entity.CompanyEntity;

public interface CompanyService {
	public CompanyEntity createCompany(CompanyEntity company,String sectorname);
	public CompanyEntity updatecompany(CompanyEntity companyEntity, CompanyEntity company, String sectorname);
}
