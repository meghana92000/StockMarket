package com.stockmarket.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.stockmarket.repository.CompanyRepository;
import com.stockmarket.repository.SectorRepository;
import com.stockmarket.entity.CompanyEntity;
import com.stockmarket.entity.SectorEntity;

@Service
@Transactional
public class CompanyServiceImpl implements CompanyService {

	@Autowired
	private SectorRepository sectorRepository;
	
	@Autowired
	private CompanyRepository companyRepository;
	
	@Override
	public CompanyEntity createCompany(CompanyEntity company, String sectorname) {
		SectorEntity sector = this.sectorRepository.findBysectorName(sectorname);
		company.setSector(sector);
		CompanyEntity companyEntity = this.companyRepository.save(company);
		return companyEntity;
	}

	public CompanyEntity updatecompany(CompanyEntity companyEntity, CompanyEntity company, String sectorname) {
		 companyEntity.setCompanyName(company.getCompanyName());
		 companyEntity.setTurnover(company.getTurnover());
		 companyEntity.setCEO(company.getCEO());
		 companyEntity.setBOD(company.getBOD());
		 companyEntity.setWriteUp(company.getWriteUp());
		 
		SectorEntity sector = this.sectorRepository.findBysectorName(sectorname);
		companyEntity.setSector(sector);
		
		CompanyEntity companyEntity2 = this.companyRepository.save(companyEntity);
		return companyEntity2;
	}

}
